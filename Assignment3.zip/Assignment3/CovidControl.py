
# Created by AMALRAJ MADATHUPARAMBIL RAJESH


#importing csv module and CovidModel class
import csv,CovidModel
#connects mysql database
import mysql.connector

mydb = mysql.connector.connect(#Establishes the connection with the database
    host="localhost",
    user="root",
    password="amal",
    database="mydatabase"
)
class CovidControl:
    
    def insertAnewRow():
        #Asks the user for the values to be inserted
        placeId = input("Enter the id :")
        placeName = input("Enter the place name :")
        placeNameFr = input("Enter the place name in French :")
        placeDate = input("Enter the date of recording in DD/MM/YYY : ")
        NumConf = input("Enter the Number Conf :")
        NumProb = input("Enter the Number Prob : ")
        NumDeath = input("Enter the Number of Death : ")
        NumTotal = input("Enter the Total Deaths : ")
        NumToday = input("Enter the Number of Deaths in this day :")
        RateTotal  = input("Enter the RateTotal : ")
        mycursor = mydb.cursor()#Creating a cursor object using the cursor() method
        sql = "INSERT INTO Covidreport(pruid, prname,prnameFR,date,numconf,numprob,numdeaths,numtotal,numtoday,ratetotal) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        val = (placeId,placeName,placeNameFr,placeDate,NumConf,NumProb,NumDeath,NumTotal,NumToday,RateTotal)
        mycursor.execute(sql, val)#executes the query
        mydb.commit()#commiting the changes
        print("\n")
        print(mycursor.rowcount, "record inserted.")#Displays the number of records inserted

    def readRow():
        #asks user for the id to select
        placeId = input("Enter the id to be selected :")
        mycursor = mydb.cursor()#Creating a cursor object using the cursor() method
        mycursor.execute("SELECT * FROM Covidreport WHERE pruid ="+placeId+"")#executes the query
        myresult = mycursor.fetchall()#fetches the data
        for x in myresult:
            print(x)#Displays the records

    def updateSpecificRow():

        #Asks the user the id to update
        updateid = input("Enter the id of the Row to be updated \n")
        #Asks the user for the updated values
        placeId = input("Enter the updated id :")
        placeName = input("Enter the updated place name :")
        placeNameFr = input("Enter the updated place name in French :")
        placeDate = input("Enter the updated date of recording in DD/MM/YYY : ")
        NumConf = input("Enter the updated Number Conf :")
        NumProb = input("Enter the updated Number Prob : ")
        NumDeath = input("Enter the updated Number of Death : ")
        NumTotal = input("Enter the updated Total Deaths : ")
        NumToday = input("Enter the updated Number of Deaths in this day :")
        RateTotal  = input("Enter the updated RateTotal : ")
        mycursor = mydb.cursor()#Creating a cursor object using the cursor() method
        sql ="UPDATE Covidreport SET pruid =%s,prname =%s,prnameFR =%s,date =%s,numconf =%s,numprob =%s,numdeaths =%s,numtotal =%s,numtoday =%s,ratetotal =%s WHERE pruid =%s"
        val = (placeId,placeName,placeNameFr,placeDate,NumConf,NumProb,NumDeath,NumTotal,NumToday,RateTotal,updateid) 
        mycursor.execute(sql,val)#executes the query
        mydb.commit()#commiting the changes
        print("\n")
        print(mycursor.rowcount, " record(s) updated ")#Displays the number of updated records

    def deleteAspecificRecord():
        #asks user for the id to delete
        placeId = input("Enter the id to be deleted :")
        mycursor = mydb.cursor()#Creating a cursor object using the cursor() method
        sql = "DELETE FROM Covidreport WHERE pruid =%s"
        val = (placeId,)
        mycursor.execute(sql,val)#executes the query
        mydb.commit()#commiting the changes
        print("\n")
        print(mycursor.rowcount, "record(s) deleted")#Displays the number of deleted records

    def dropTable():
        mycursor = mydb.cursor()
        sql = "DROP TABLE Covidreport"
        mycursor.execute(sql)
