
# Program using python to Create, read, update, delete records from a csv file to database
# Created by AMALRAJ MADATHUPARAMBIL RAJESH 

#importing csv module
import csv
#connects mysql database
import mysql.connector
mydb = mysql.connector.connect(#Establishes the connection with the database
    host="localhost",
    user="root",
    password="amal",
    database="mydatabase")

class CovidModel:
    #Constructors and methods
    def __init__(self,pruid,prname,prnameFR,date,numconf,numprob,numdeaths,numtotal,numtoday,ratetotal):
        self.pruid = pruid
        self.prname = prname
        self.prnameFR = prnameFR
        self.date = date
        self.numconf = numconf
        self.numprob = numprob
        self.numdeaths = numdeaths
        self.numtotal = numtotal
        self.numtoday = numtoday
        self.ratetotal = ratetotal

    def get_pruid(self):
        return self.pruid

    def get_prname(self):
        return self.prname

    def get_prnameFR(self):
        return self.prnameFR

    def get_date(self):
        return self.date

    def get_numconf(self):
        return self.numconf

    def get_numprob(self):
        return self.numprob

    def get_numdeaths(self):
        return self.numdeaths

    def get_numtotal(self):
        return self.numtotal

    def get_numtoday(self):
        return self.numtoday

    def get_ratetotal(self):
        return self.ratetotal

def readCSVFile():
    print("\n")
    try:
        mycursor =mydb.cursor()#Creating a cursor object using the cursor() method
        mycursor.execute("DROP TABLE IF EXISTS Covidreport")#Drops the table if created before
        #Creates a new Table
        mycursor.execute("create table Covidreport(pruid VARCHAR(25),prname VARCHAR(25),prnameFR VARCHAR(25),date VARCHAR(25),numconf VARCHAR(25),numprob VARCHAR(25),numdeaths VARCHAR(25),numtotal VARCHAR(25),numtoday VARCHAR(25),ratetotal VARCHAR(25))")

        with open('covid19-download.csv') as csv_file:
            csvfile = csv.reader(csv_file,delimiter=',')
            all_value =  []
            for row in csvfile:#reads the csv file
                value = (row[0],row[1],row[2],row[3],row[5],row[6],row[7],row[8],row[13],row[15])#Reads the required rows
                all_value.append(value)#appends the value from 'value' to 'all_value'
        #sql statement to Insert the appended value to the database
        sql = "INSERT INTO Covidreport(pruid, prname,prnameFR,date,numconf,numprob,numdeaths,numtotal,numtoday,ratetotal) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        mycursor.executemany(sql,all_value)#Executes the appended value to the database
        mydb.commit()#commiting the changes
        print(mycursor.rowcount, "record inserted.")#Displays the number of records
    #Exception incase of missing file    
    except IOError:
        print('File Not found')