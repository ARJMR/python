
# Created by AMALRAJ MADATHUPARAMBIL RAJESH 

class CovidView:

    def displayName():
        print('Programmed by Amalraj Madathiparambil Rajesh\n')

    def menu():
        """Menu for user input"""
        print('Select an option(1-6):')
        print('1: Import the data from CSV file to database')
        print('2: Insert a new row')
        print('3: Read a Specific row ')
        print('4: Update a Specific row ')
        print('5: Delete a specific row')
        print('6: Drop the table')
        print('7: Quit\n')


    