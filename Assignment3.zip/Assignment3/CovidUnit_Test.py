
# Author: Amalraj Madathiparambil Rajesh


#Imported unittest framework and mysql database connection
import unittest
import mysql.connector
#imports the methods from covid model class
from CovidModel import readCSVFile
#Establishes the connection with the database
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="amal",
    database="mydatabase")

class CovidUnit_Test(unittest.TestCase):
  #this method checks if the table is empty
    def test_Covidreport(self):
        mycursor = mydb.cursor()
        mycursor.execute("SELECT * FROM Covidreport")
        myresult = mycursor.fetchall()
        assert len(myresult) != 0
    print('Programmed By Amalraj Madathiparambil Rajesh')

if __name__ == '__main__':
    unittest.main()
