
# Program using python to Create, read, update, delete records from a csv file to database
# Created by AMALRAJ MADATHUPARAMBIL RAJESH


#importing CovidModel,CovidView andd CovidControl class
import CovidView,CovidModel
from CovidView import CovidView
import CovidControl
from CovidControl import CovidControl

class CovidMain:
    def main():

        CovidView.menu()

        Option = 0
        while Option < 7:
            Option = int(input('Please enter from given option(1-5, 6 to exit): '))
            print('\n')
            """Menu for user input"""
            if Option == 1:

                CovidModel.readCSVFile()
                print('Imported CSV File to Database...\n')
                CovidView.displayName()
                CovidView.menu()
                print('\n')

            elif Option == 2:
                CovidControl.insertAnewRow()
                print('\n')
                CovidView.displayName()
                CovidView.menu()
                print('\n')

            elif Option == 3:
                CovidControl.readRow()
                print('\n')
                CovidView.displayName()
                CovidView.menu()
                print('\n')

            elif Option == 4:
                CovidControl.updateSpecificRow()
                print('\n')
                CovidView.displayName()
                CovidView.menu()
                print('\n')

            elif Option == 5:
                CovidControl.deleteAspecificRecord()
                print('\nRecord Deleted\n')
                CovidView.displayName()
                print('\n')
                CovidView.menu()
                print('\n')

            elif Option == 6:
                CovidControl.dropTable()
                print('\nTable Dropped\n')
                CovidView.displayName()
                print('\n')
                CovidView.menu()
                print('\n')

            elif Option == 7:
                print('Exiting Program\n')
                CovidView.displayName()
                break
            else:
                print('Invalid input')
                print('\n')
                CovidView.menu()
                Option = 0
    if __name__ == '__main__':
        main()